package com.daily.planner.ui

import android.app.Application
import androidx.lifecycle.*
import com.daily.planner.data.db.AppDatabase
import com.daily.planner.data.model.*
import com.daily.planner.data.repository.AppRepository
import com.daily.planner.util.DateUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val repo = AppRepository(db.todoDao(), db.noteDao(), db.moodDao(), db.routineDao())

    // ── Selected date ──
    private val _selectedDate = MutableStateFlow(DateUtils.today())
    val selectedDate: StateFlow<String> = _selectedDate

    fun selectDate(dateKey: String) { _selectedDate.value = dateKey }

    // ── Todos for selected date ──
    val todosForSelectedDate: StateFlow<List<Todo>> = _selectedDate
        .flatMapLatest { repo.getTodosForDate(it) }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Todos for today (header badge) ──
    val todosToday: StateFlow<List<Todo>> = repo.getTodosForDate(DateUtils.today())
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Daily stats (for calendar dots + summary) ──
    val dailyStats = repo.getDailyStats()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Notes ──
    val notes = repo.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Mood today ──
    val moodToday: StateFlow<Mood?> = repo.getMoodForDate(DateUtils.today())
        .stateIn(viewModelScope, SharingStarted.Lazily, null)

    val recentMoods = repo.getRecentMoods()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Routines ──
    val routineItems = repo.getAllRoutineItems()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val routineChecksToday = repo.getRoutineChecksForDate(DateUtils.today())
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val routineChecksSinceYearStart = repo.getRoutineChecksSince(DateUtils.yearStartKey())
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Actions: Todos ──
    fun addTodo(text: String) = viewModelScope.launch {
        repo.insertTodo(Todo(dateKey = _selectedDate.value, text = text))
    }

    fun toggleTodo(todo: Todo) = viewModelScope.launch {
        repo.updateTodo(todo.copy(isDone = !todo.isDone))
    }

    fun deleteTodo(todo: Todo) = viewModelScope.launch {
        repo.deleteTodo(todo.id)
    }

    // ── Actions: Notes ──
    fun saveNote(note: Note) = viewModelScope.launch {
        if (note.id == 0L) repo.insertNote(note) else repo.updateNote(note)
    }

    fun deleteNote(id: Long) = viewModelScope.launch { repo.deleteNote(id) }

    // ── Actions: Mood ──
    fun setMood(index: Int) = viewModelScope.launch {
        val today = DateUtils.today()
        if (moodToday.value?.moodIndex == index) repo.clearMood(today)
        else repo.setMood(today, index)
    }

    // ── Actions: Routines ──
    fun addRoutineItem(title: String) = viewModelScope.launch {
        repo.insertRoutineItem(RoutineItem(title = title))
    }

    fun renameRoutineItem(item: RoutineItem, newTitle: String) = viewModelScope.launch {
        repo.updateRoutineItem(item.copy(title = newTitle))
    }

    fun deleteRoutineItem(id: Long) = viewModelScope.launch {
        repo.deleteRoutineItem(id)
    }

    fun toggleRoutineCheck(itemId: Long, dateKey: String, currentState: Boolean) = viewModelScope.launch {
        repo.toggleRoutineCheck(itemId, dateKey, currentState)
    }
}

class MainViewModelFactory(private val app: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return MainViewModel(app) as T
    }
}
