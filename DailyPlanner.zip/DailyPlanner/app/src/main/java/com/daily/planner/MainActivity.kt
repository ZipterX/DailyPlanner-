package com.daily.planner

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.daily.planner.databinding.ActivityMainBinding
import com.daily.planner.ui.MainViewModel
import com.daily.planner.ui.MainViewModelFactory
import com.daily.planner.util.DateUtils
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    val viewModel: MainViewModel by viewModels { MainViewModelFactory(application) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Make status bar transparent
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Navigation
        val navHost = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHost.navController
        binding.bottomNav.setupWithNavController(navController)

        // Update header badges
        lifecycleScope.launch {
            viewModel.todosToday.collect { todos ->
                val done = todos.count { it.isDone }
                binding.badgeTasks.text = "$done/${todos.size}"
            }
        }
        lifecycleScope.launch {
            viewModel.routineItems.collect { items ->
                val checks = viewModel.routineChecksToday.value
                val done = checks.count { it.isDone }
                binding.badgeRoutine.text = "$done/${items.size}"
            }
        }
        lifecycleScope.launch {
            viewModel.routineChecksToday.collect { checks ->
                val items = viewModel.routineItems.value
                val done = checks.count { it.isDone }
                binding.badgeRoutine.text = "$done/${items.size}"
            }
        }

        // Date header
        val today = DateUtils.today()
        val date = DateUtils.parse(today)
        val fmt = java.time.format.DateTimeFormatter.ofPattern("EEEE, MMMM d")
        binding.tvDate.text = date.format(fmt)
    }
}
