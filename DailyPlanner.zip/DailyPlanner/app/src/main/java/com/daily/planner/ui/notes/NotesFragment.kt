package com.daily.planner.ui.notes

import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.daily.planner.data.model.Note
import com.daily.planner.databinding.*
import com.daily.planner.ui.MainViewModel
import com.daily.planner.ui.MainViewModelFactory
import com.daily.planner.util.DateUtils
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter

class NotesFragment : Fragment() {
    private var _b: FragmentNotesBinding? = null
    private val b get() = _b!!
    private val vm: MainViewModel by activityViewModels { MainViewModelFactory(requireActivity().application) }
    private lateinit var adapter: NoteAdapter
    private var editNote: Note? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentNotesBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)

        // Mood buttons
        val moodBtns = listOf(b.mood0, b.mood1, b.mood2, b.mood3, b.mood4)
        moodBtns.forEachIndexed { i, btn -> btn.setOnClickListener { vm.setMood(i) } }

        viewLifecycleOwner.lifecycleScope.launch {
            vm.moodToday.collect { mood ->
                moodBtns.forEachIndexed { i, btn ->
                    btn.alpha = if (mood?.moodIndex == i) 1f else 0.4f
                    btn.scaleX = if (mood?.moodIndex == i) 1.15f else 1f
                    btn.scaleY = if (mood?.moodIndex == i) 1.15f else 1f
                }
            }
        }

        adapter = NoteAdapter(
            onEdit = { openEditNote(it) },
            onDelete = { vm.deleteNote(it.id) }
        )
        b.rvNotes.layoutManager = LinearLayoutManager(requireContext())
        b.rvNotes.adapter = adapter

        b.btnNewNote.setOnClickListener { openEditNote(null) }
        b.btnSaveNote.setOnClickListener { saveNote() }
        b.btnCancelNote.setOnClickListener { closeForm() }

        viewLifecycleOwner.lifecycleScope.launch {
            vm.notes.collect { notes ->
                adapter.submitList(notes)
                b.tvNoteCount.text = "${notes.size} saved"
                b.tvEmpty.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
            }
        }

        closeForm()
    }

    private fun openEditNote(note: Note?) {
        editNote = note
        b.formNote.visibility = View.VISIBLE
        b.listSection.visibility = View.GONE
        b.etNoteTitle.setText(note?.title ?: "")
        b.etNoteBody.setText(note?.body ?: "")
        b.etNoteDate.setText(note?.dateKey ?: DateUtils.today())
        b.btnSaveNote.text = if (note != null) "Update" else "Save"
    }

    private fun closeForm() {
        b.formNote.visibility = View.GONE
        b.listSection.visibility = View.VISIBLE
        editNote = null
    }

    private fun saveNote() {
        val title = b.etNoteTitle.text?.toString()?.trim() ?: ""
        val body = b.etNoteBody.text?.toString()?.trim() ?: ""
        val date = b.etNoteDate.text?.toString()?.trim() ?: DateUtils.today()
        if (body.isEmpty() && title.isEmpty()) { closeForm(); return }
        val note = Note(id = editNote?.id ?: 0L, title = title, body = body, dateKey = date, color = editNote?.color ?: "#c48a3c")
        vm.saveNote(note)
        closeForm()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}

class NoteAdapter(
    private val onEdit: (Note) -> Unit,
    private val onDelete: (Note) -> Unit
) : ListAdapter<Note, NoteAdapter.VH>(DIFF) {

    inner class VH(val b: ItemNoteBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemNoteBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val n = getItem(pos)
        with(h.b) {
            tvTitle.text = n.title.ifEmpty { "Untitled" }
            tvBody.text = n.body
            val fmt = DateTimeFormatter.ofPattern("EEE, MMM d")
            tvDate.text = "📅 ${DateUtils.parse(n.dateKey).format(fmt)}"
            btnEdit.setOnClickListener { onEdit(n) }
            btnDelete.setOnClickListener { onDelete(n) }
            try {
                val color = android.graphics.Color.parseColor(n.color)
                accentBar.setBackgroundColor(color)
            } catch (_: Exception) {}
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Note>() {
            override fun areItemsTheSame(a: Note, b: Note) = a.id == b.id
            override fun areContentsTheSame(a: Note, b: Note) = a == b
        }
    }
}
