package com.daily.planner.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter

object DateUtils {
    private val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    fun today(): String = LocalDate.now().format(fmt)

    fun dateKey(date: LocalDate): String = date.format(fmt)

    fun parse(key: String): LocalDate = LocalDate.parse(key, fmt)

    fun weekStartKey(): String = dateKey(LocalDate.now().with(java.time.DayOfWeek.SUNDAY))

    fun monthStartKey(): String {
        val now = LocalDate.now()
        return dateKey(now.withDayOfMonth(1))
    }

    fun yearStartKey(): String {
        val now = LocalDate.now()
        return dateKey(now.withDayOfYear(1))
    }

    fun keysInRange(from: String, to: String): List<String> {
        val result = mutableListOf<String>()
        var cur = parse(from)
        val end = parse(to)
        while (!cur.isAfter(end)) {
            result.add(dateKey(cur))
            cur = cur.plusDays(1)
        }
        return result
    }

    fun shortDayLabel(dateKey: String): String {
        val d = parse(dateKey)
        return when (d.dayOfWeek) {
            java.time.DayOfWeek.SUNDAY -> "Su"
            java.time.DayOfWeek.MONDAY -> "Mo"
            java.time.DayOfWeek.TUESDAY -> "Tu"
            java.time.DayOfWeek.WEDNESDAY -> "We"
            java.time.DayOfWeek.THURSDAY -> "Th"
            java.time.DayOfWeek.FRIDAY -> "Fr"
            java.time.DayOfWeek.SATURDAY -> "Sa"
        }
    }

    fun weekKeysForDate(dateKey: String): List<String> {
        val d = parse(dateKey)
        val sunday = d.with(java.time.DayOfWeek.SUNDAY)
        return (0..6).map { dateKey(sunday.plusDays(it.toLong())) }
    }

    fun currentWeekKeys(): List<String> = weekKeysForDate(today())
}

object AppColors {
    const val BG       = 0xFF1A1814.toInt()
    const val CARD     = 0xFF221F1B.toInt()
    const val CARD2    = 0xFF2A2620.toInt()
    const val AMBER    = 0xFFC48A3C.toInt()
    const val AMBER2   = 0xFFE8A84A.toInt()
    const val CREAM    = 0xFFE8DCC8.toInt()
    const val CREAMY   = 0xFFB8AA94.toInt()
    const val MUTED    = 0xFF6B6254.toInt()
    const val GREEN    = 0xFF7AB87A.toInt()
    const val RED      = 0xFFC47A6A.toInt()
    const val BLUE     = 0xFF7AAAC4.toInt()
    const val PURPLE   = 0xFFA47AC4.toInt()
    const val BORDER   = 0x33C48A3C.toInt()
    const val BORDER2  = 0x16FFFFFF.toInt()
}
