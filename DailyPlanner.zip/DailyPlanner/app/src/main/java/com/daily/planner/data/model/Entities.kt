package com.daily.planner.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ── Todo ──────────────────────────────────────────────────────────────────────
@Entity(tableName = "todos")
data class Todo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateKey: String,          // "YYYY-MM-DD"
    val text: String,
    val isDone: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ── Note ──────────────────────────────────────────────────────────────────────
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val body: String,
    val dateKey: String,
    val color: String = "#c48a3c",
    val createdAt: Long = System.currentTimeMillis()
)

// ── Mood ──────────────────────────────────────────────────────────────────────
@Entity(tableName = "moods")
data class Mood(
    @PrimaryKey val dateKey: String,
    val moodIndex: Int            // 0–4
)

// ── RoutineItem ───────────────────────────────────────────────────────────────
@Entity(tableName = "routine_items")
data class RoutineItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

// ── RoutineCheck ──────────────────────────────────────────────────────────────
@Entity(tableName = "routine_checks", primaryKeys = ["itemId", "dateKey"])
data class RoutineCheck(
    val itemId: Long,
    val dateKey: String,
    val isDone: Boolean = false
)
