package com.daily.planner.data.db

import androidx.room.*
import com.daily.planner.data.model.*
import kotlinx.coroutines.flow.Flow

// ── TodoDao ───────────────────────────────────────────────────────────────────
@Dao
interface TodoDao {
    @Query("SELECT * FROM todos WHERE dateKey = :dateKey ORDER BY createdAt ASC")
    fun getTodosForDate(dateKey: String): Flow<List<Todo>>

    @Query("SELECT dateKey, COUNT(*) as total, SUM(CASE WHEN isDone=1 THEN 1 ELSE 0 END) as done FROM todos GROUP BY dateKey")
    fun getDailyStats(): Flow<List<DailyStat>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(todo: Todo): Long

    @Update
    suspend fun update(todo: Todo)

    @Delete
    suspend fun delete(todo: Todo)

    @Query("DELETE FROM todos WHERE id = :id")
    suspend fun deleteById(id: Long)
}

data class DailyStat(val dateKey: String, val total: Int, val done: Int)

// ── NoteDao ───────────────────────────────────────────────────────────────────
@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: Note): Long

    @Update
    suspend fun update(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)
}

// ── MoodDao ───────────────────────────────────────────────────────────────────
@Dao
interface MoodDao {
    @Query("SELECT * FROM moods WHERE dateKey = :dateKey LIMIT 1")
    fun getMoodForDate(dateKey: String): Flow<Mood?>

    @Query("SELECT * FROM moods ORDER BY dateKey DESC LIMIT 30")
    fun getRecentMoods(): Flow<List<Mood>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(mood: Mood)

    @Query("DELETE FROM moods WHERE dateKey = :dateKey")
    suspend fun deleteForDate(dateKey: String)
}

// ── RoutineDao ────────────────────────────────────────────────────────────────
@Dao
interface RoutineDao {
    @Query("SELECT * FROM routine_items ORDER BY sortOrder ASC, createdAt ASC")
    fun getAllItems(): Flow<List<RoutineItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: RoutineItem): Long

    @Update
    suspend fun updateItem(item: RoutineItem)

    @Query("DELETE FROM routine_items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM routine_checks WHERE itemId = :itemId")
    suspend fun deleteChecksForItem(itemId: Long)

    @Query("SELECT * FROM routine_checks WHERE dateKey = :dateKey")
    fun getChecksForDate(dateKey: String): Flow<List<RoutineCheck>>

    @Query("SELECT * FROM routine_checks WHERE dateKey >= :fromDate")
    fun getChecksSince(fromDate: String): Flow<List<RoutineCheck>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCheck(check: RoutineCheck)

    @Query("DELETE FROM routine_checks WHERE itemId = :itemId AND dateKey = :dateKey")
    suspend fun deleteCheck(itemId: Long, dateKey: String)
}
