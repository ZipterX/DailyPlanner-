package com.daily.planner.ui.checklist

import android.view.*
import androidx.recyclerview.widget.*
import com.daily.planner.data.model.Todo
import com.daily.planner.databinding.ItemTodoBinding
import com.daily.planner.databinding.ItemCalendarDayBinding
import com.daily.planner.util.DateUtils
import java.time.LocalDate
import java.time.YearMonth

// ── TodoAdapter ───────────────────────────────────────────────────────────────
class TodoAdapter(
    private val onToggle: (Todo) -> Unit,
    private val onDelete: (Todo) -> Unit
) : ListAdapter<Todo, TodoAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemTodoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val todo = getItem(position)
        with(holder.binding) {
            tvText.text = todo.text
            tvText.alpha = if (todo.isDone) 0.45f else 1f
            tvText.paintFlags = if (todo.isDone)
                tvText.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            else
                tvText.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv()
            checkBox.isChecked = todo.isDone
            checkBox.setOnClickListener { onToggle(todo) }
            btnDelete.setOnClickListener { onDelete(todo) }
            root.alpha = if (todo.isDone) 0.75f else 1f
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Todo>() {
            override fun areItemsTheSame(a: Todo, b: Todo) = a.id == b.id
            override fun areContentsTheSame(a: Todo, b: Todo) = a == b
        }
    }
}

// ── CalendarAdapter ───────────────────────────────────────────────────────────
class CalendarAdapter(
    private val onDateClick: (String) -> Unit
) : RecyclerView.Adapter<CalendarAdapter.VH>() {

    private var yearMonth = YearMonth.now()
    private var selectedKey = DateUtils.today()
    private var stats: Map<String, Pair<Int, Int>> = emptyMap()
    var onMonthChanged: ((Int, Int) -> Unit)? = null

    private val cells = mutableListOf<LocalDate?>()

    init { buildCells() }

    private fun buildCells() {
        cells.clear()
        val firstDay = yearMonth.atDay(1).dayOfWeek.value % 7 // 0=Sun
        repeat(firstDay) { cells.add(null) }
        for (d in 1..yearMonth.lengthOfMonth()) cells.add(yearMonth.atDay(d))
        while (cells.size % 7 != 0) cells.add(null)
        notifyDataSetChanged()
        onMonthChanged?.invoke(yearMonth.year, yearMonth.monthValue)
    }

    fun prevMonth() { yearMonth = yearMonth.minusMonths(1); buildCells() }
    fun nextMonth() { yearMonth = yearMonth.plusMonths(1); buildCells() }
    fun setSelected(key: String) { selectedKey = key; notifyDataSetChanged() }
    fun setStats(s: Map<String, Pair<Int, Int>>) { stats = s; notifyDataSetChanged() }

    inner class VH(val b: ItemCalendarDayBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemCount() = cells.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCalendarDayBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val date = cells[position]
        val b = holder.b
        if (date == null) {
            b.root.visibility = View.INVISIBLE
            return
        }
        b.root.visibility = View.VISIBLE
        val key = DateUtils.dateKey(date)
        val isToday = key == DateUtils.today()
        val isSel = key == selectedKey
        val stat = stats[key]

        b.tvDay.text = date.dayOfMonth.toString()

        // Dot
        when {
            stat == null || stat.second == 0 -> b.dot.visibility = View.INVISIBLE
            stat.first == stat.second -> { b.dot.visibility = View.VISIBLE; b.dot.setBackgroundResource(android.R.drawable.presence_online) }
            stat.first > 0 -> { b.dot.visibility = View.VISIBLE; b.dot.setBackgroundResource(android.R.drawable.presence_away) }
            else -> b.dot.visibility = View.INVISIBLE
        }

        // Style
        when {
            isSel -> {
                b.root.setBackgroundResource(com.daily.planner.R.drawable.bg_cal_selected)
                b.tvDay.setTextColor(0xFF1A1410.toInt())
            }
            isToday -> {
                b.root.setBackgroundResource(com.daily.planner.R.drawable.bg_cal_today)
                b.tvDay.setTextColor(0xFFE8A84A.toInt())
            }
            else -> {
                b.root.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                b.tvDay.setTextColor(0xFFE8DCC8.toInt())
            }
        }

        b.root.setOnClickListener { onDateClick(key) }
    }
}
