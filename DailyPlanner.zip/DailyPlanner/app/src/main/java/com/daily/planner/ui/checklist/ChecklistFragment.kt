package com.daily.planner.ui.checklist

import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.daily.planner.MainActivity
import com.daily.planner.R
import com.daily.planner.databinding.FragmentChecklistBinding
import com.daily.planner.ui.MainViewModel
import com.daily.planner.ui.MainViewModelFactory
import com.daily.planner.util.DateUtils
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class ChecklistFragment : Fragment() {
    private var _binding: FragmentChecklistBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels { MainViewModelFactory(requireActivity().application) }
    private lateinit var todoAdapter: TodoAdapter
    private lateinit var calendarAdapter: CalendarAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentChecklistBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupCalendar()
        setupTodoList()
        setupInput()
        observeData()
    }

    private fun setupCalendar() {
        calendarAdapter = CalendarAdapter(
            onDateClick = { dateKey ->
                viewModel.selectDate(dateKey)
            }
        )
        binding.rvCalendar.apply {
            layoutManager = GridLayoutManager(requireContext(), 7)
            adapter = calendarAdapter
        }

        // Month nav
        binding.btnPrevMonth.setOnClickListener { calendarAdapter.prevMonth() }
        binding.btnNextMonth.setOnClickListener { calendarAdapter.nextMonth() }
        calendarAdapter.onMonthChanged = { year, month ->
            val fmt = DateTimeFormatter.ofPattern("MMMM yyyy")
            binding.tvMonthYear.text = LocalDate.of(year, month, 1).format(fmt)
        }
    }

    private fun setupTodoList() {
        todoAdapter = TodoAdapter(
            onToggle = { viewModel.toggleTodo(it) },
            onDelete = { viewModel.deleteTodo(it) }
        )
        binding.rvTodos.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = todoAdapter
            itemAnimator = DefaultItemAnimator()
        }
    }

    private fun setupInput() {
        binding.etNewTodo.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { addTodo(); true } else false
        }
        binding.btnAddTodo.setOnClickListener { addTodo() }
    }

    private fun addTodo() {
        val text = binding.etNewTodo.text?.toString()?.trim() ?: return
        if (text.isEmpty()) return
        viewModel.addTodo(text)
        binding.etNewTodo.text?.clear()
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.todosForSelectedDate.collect { todos ->
                todoAdapter.submitList(todos)
                val done = todos.count { it.isDone }
                val total = todos.size
                val pct = if (total > 0) (done * 100 / total) else 0
                binding.tvProgress.text = "$done/$total"
                binding.tvProgressPct.text = "$pct%"
                binding.progressBar.progress = pct
                binding.cardProgress.visibility = if (total > 0) View.VISIBLE else View.GONE
                binding.tvEmpty.visibility = if (total == 0) View.VISIBLE else View.GONE
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.selectedDate.collect { dateKey ->
                val isToday = dateKey == DateUtils.today()
                val fmt = DateTimeFormatter.ofPattern("EEEE, MMM d")
                val label = if (isToday) "📌 Today" else "📅 ${DateUtils.parse(dateKey).format(fmt)}"
                binding.tvSelectedDate.text = label
                binding.btnGoToday.visibility = if (isToday) View.GONE else View.VISIBLE
                val hint = if (isToday) "Add a task for today…" else "Add task…"
                binding.etNewTodo.hint = hint
                calendarAdapter.setSelected(dateKey)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.dailyStats.collect { stats ->
                calendarAdapter.setStats(stats.associate { it.dateKey to Pair(it.done, it.total) })
            }
        }

        binding.btnGoToday.setOnClickListener { viewModel.selectDate(DateUtils.today()) }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
