package com.daily.planner.ui.routine

import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.daily.planner.data.model.*
import com.daily.planner.databinding.*
import com.daily.planner.ui.MainViewModel
import com.daily.planner.ui.MainViewModelFactory
import com.daily.planner.util.DateUtils
import kotlinx.coroutines.launch

class RoutineFragment : Fragment() {
    private var _b: FragmentRoutineBinding? = null
    private val b get() = _b!!
    private val vm: MainViewModel by activityViewModels { MainViewModelFactory(requireActivity().application) }
    private lateinit var adapter: RoutineTableAdapter

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentRoutineBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        setupInput()
        setupTable()
        observeData()
    }

    private fun setupInput() {
        b.etNewRoutine.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { addRoutine(); true } else false
        }
        b.btnAddRoutine.setOnClickListener { addRoutine() }
        b.btnManage.setOnClickListener { showManageDialog() }
    }

    private fun addRoutine() {
        val text = b.etNewRoutine.text?.toString()?.trim() ?: return
        if (text.isEmpty()) return
        vm.addRoutineItem(text)
        b.etNewRoutine.text?.clear()
    }

    private fun setupTable() {
        adapter = RoutineTableAdapter(
            weekDays = DateUtils.currentWeekKeys(),
            onToggle = { itemId, dateKey, state -> vm.toggleRoutineCheck(itemId, dateKey, state) }
        )
        b.rvRoutineTable.layoutManager = LinearLayoutManager(requireContext())
        b.rvRoutineTable.adapter = adapter
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            vm.routineItems.collect { items ->
                b.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                b.btnManage.visibility = if (items.isNotEmpty()) View.VISIBLE else View.GONE
                adapter.setItems(items)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            vm.routineChecksSinceYearStart.collect { checks ->
                adapter.setChecks(checks)
                // Update today progress
                val items = vm.routineItems.value
                val today = DateUtils.today()
                val todayDone = checks.count { it.dateKey == today && it.isDone }
                val total = items.size
                val pct = if (total > 0) (todayDone * 100 / total) else 0
                b.tvTodayProgress.text = "$todayDone/$total"
                b.tvTodayPct.text = "$pct%"
                b.progressToday.progress = pct
                b.cardTodayProgress.visibility = if (total > 0) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showManageDialog() {
        val items = vm.routineItems.value
        if (items.isEmpty()) return
        val names = items.map { it.title }.toTypedArray()
        AlertDialog.Builder(requireContext())
            .setTitle("Manage Routines")
            .setItems(names) { _, idx ->
                val item = items[idx]
                showItemOptions(item)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showItemOptions(item: RoutineItem) {
        AlertDialog.Builder(requireContext())
            .setTitle(item.title)
            .setItems(arrayOf("✏️ Rename", "🗑 Delete")) { _, idx ->
                when (idx) {
                    0 -> showRenameDialog(item)
                    1 -> showDeleteConfirm(item)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRenameDialog(item: RoutineItem) {
        val input = android.widget.EditText(requireContext()).apply {
            setText(item.title)
            hint = "New name"
            setPadding(48, 32, 48, 16)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Rename Routine")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newTitle = input.text?.toString()?.trim() ?: return@setPositiveButton
                if (newTitle.isNotEmpty()) vm.renameRoutineItem(item, newTitle)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirm(item: RoutineItem) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete \"${item.title}\"?")
            .setMessage("All check history will be permanently removed.")
            .setPositiveButton("Delete") { _, _ -> vm.deleteRoutineItem(item.id) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}

// ── Routine Table Adapter (one row per routine, columns = 7 days) ─────────────
class RoutineTableAdapter(
    private val weekDays: List<String>,
    private val onToggle: (Long, String, Boolean) -> Unit
) : RecyclerView.Adapter<RoutineTableAdapter.VH>() {

    private var items = listOf<RoutineItem>()
    private var checks = listOf<RoutineCheck>()

    fun setItems(i: List<RoutineItem>) { items = i; notifyDataSetChanged() }
    fun setChecks(c: List<RoutineCheck>) { checks = c; notifyDataSetChanged() }

    private fun isChecked(itemId: Long, dateKey: String) =
        checks.any { it.itemId == itemId && it.dateKey == dateKey && it.isDone }

    private fun weekDoneCount(itemId: Long) = weekDays.count { isChecked(itemId, it) }

    inner class VH(val b: ItemRoutineRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemRoutineRowBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = items[pos]
        val today = DateUtils.today()
        with(h.b) {
            tvRoutineName.text = item.title
            val wDone = weekDoneCount(item.id)
            tvWeekProgress.text = "$wDone/7 this week"
            tvWeekProgress.setTextColor(
                when { wDone == 7 -> 0xFF7AB87A.toInt(); wDone >= 4 -> 0xFFE8A84A.toInt(); else -> 0xFF6B6254.toInt() }
            )
            val checkViews = listOf(cbSu, cbMo, cbTu, cbWe, cbTh, cbFr, cbSa)
            checkViews.forEachIndexed { i, cb ->
                val dk = weekDays[i]
                val chk = isChecked(item.id, dk)
                cb.isChecked = chk
                cb.setOnClickListener { onToggle(item.id, dk, chk) }
                cb.alpha = if (dk == today) 1f else 0.75f
            }
        }
    }
}
