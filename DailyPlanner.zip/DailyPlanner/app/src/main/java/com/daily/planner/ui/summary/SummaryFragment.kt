package com.daily.planner.ui.summary

import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.daily.planner.databinding.FragmentSummaryBinding
import com.daily.planner.ui.MainViewModel
import com.daily.planner.ui.MainViewModelFactory
import com.daily.planner.util.DateUtils
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class SummaryFragment : Fragment() {
    private var _b: FragmentSummaryBinding? = null
    private val b get() = _b!!
    private val vm: MainViewModel by activityViewModels { MainViewModelFactory(requireActivity().application) }
    private var currentPeriod = "week"

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSummaryBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        setupPeriodToggle()
        setupCharts()
        observeData()
    }

    private fun setupPeriodToggle() {
        listOf(b.btnDay, b.btnWeek, b.btnMonth, b.btnYear).forEachIndexed { i, btn ->
            val periods = listOf("day","week","month","year")
            btn.setOnClickListener { currentPeriod = periods[i]; updateSummary() }
        }
    }

    private fun setupCharts() {
        // Bar chart style
        b.barChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = 0xFF6B6254.toInt()
                textSize = 9f
                granularity = 1f
            }
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = 0x22FFFFFF
                textColor = 0xFF6B6254.toInt()
                axisMinimum = 0f
            }
            axisRight.isEnabled = false
            animateY(600)
        }

        // Pie/Donut chart
        b.pieChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 68f
            transparentCircleRadius = 72f
            setHoleColor(Color.TRANSPARENT)
            setTransparentCircleColor(Color.TRANSPARENT)
            setBackgroundColor(Color.TRANSPARENT)
            animateY(800)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            vm.dailyStats.collect { updateSummary() }
        }
    }

    private fun updateSummary() {
        val stats = vm.dailyStats.value
        val today = DateUtils.today()
        val now = java.time.LocalDate.now()

        // Determine date range
        val (keys, labels) = when (currentPeriod) {
            "day" -> {
                val k = listOf(today)
                val l = listOf("Today")
                k to l
            }
            "week" -> {
                val wk = DateUtils.currentWeekKeys()
                val lb = listOf("Su","Mo","Tu","We","Th","Fr","Sa")
                wk to lb
            }
            "month" -> {
                val start = DateUtils.monthStartKey()
                val wks = DateUtils.keysInRange(start, today).chunked(7)
                val k = wks.map { it.last() }
                val l = wks.mapIndexed { i, _ -> "W${i+1}" }
                k to l
            }
            "year" -> {
                val months = (1..12).map { m ->
                    val mDate = now.withMonth(m).withDayOfMonth(1)
                    DateUtils.dateKey(mDate)
                }
                val l = listOf("J","F","M","A","M","J","J","A","S","O","N","D")
                months to l
            }
            else -> emptyList<String>() to emptyList()
        }

        val statMap = stats.associate { it.dateKey to it }

        // Aggregate
        val aggregated = when (currentPeriod) {
            "month" -> {
                val start = DateUtils.monthStartKey()
                DateUtils.keysInRange(start, today).chunked(7).map { chunk ->
                    val done = chunk.sumOf { statMap[it]?.done ?: 0 }
                    val total = chunk.sumOf { statMap[it]?.total ?: 0 }
                    done to total
                }
            }
            "year" -> {
                (1..12).map { m ->
                    val mStart = DateUtils.dateKey(now.withMonth(m).withDayOfMonth(1))
                    val mEnd = DateUtils.dateKey(now.withMonth(m).withDayOfMonth(
                        now.withMonth(m).lengthOfMonth()))
                    val effectiveEnd = if (mEnd > today) today else mEnd
                    if (mStart > today) 0 to 0
                    else {
                        val range = DateUtils.keysInRange(mStart, effectiveEnd)
                        val done = range.sumOf { statMap[it]?.done ?: 0 }
                        val total = range.sumOf { statMap[it]?.total ?: 0 }
                        done to total
                    }
                }
            }
            else -> keys.map { k ->
                val s = statMap[k]
                (s?.done ?: 0) to (s?.total ?: 0)
            }
        }

        val totalDone = aggregated.sumOf { it.first }
        val totalTasks = aggregated.sumOf { it.second }
        val rate = if (totalTasks > 0) (totalDone * 100 / totalTasks) else 0

        // Update stat cards
        b.tvDone.text = "$totalDone"
        b.tvTotal.text = "$totalTasks"
        b.tvRate.text = "$rate%"

        // Bar chart entries
        val barEntries = aggregated.mapIndexed { i, (done, _) ->
            BarEntry(i.toFloat(), done.toFloat())
        }
        val dataSet = BarDataSet(barEntries, "Done").apply {
            color = 0xFFC48A3C.toInt()
            setDrawValues(false)
        }
        b.barChart.data = BarData(dataSet).apply { barWidth = 0.6f }
        b.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        b.barChart.xAxis.labelCount = labels.size
        b.barChart.invalidate()

        // Donut chart
        val remaining = totalTasks - totalDone
        val pieEntries = if (totalTasks > 0) listOf(
            PieEntry(totalDone.toFloat(), "Done"),
            PieEntry(remaining.toFloat().coerceAtLeast(0f), "Left")
        ) else listOf(PieEntry(1f, ""))
        val pieSet = PieDataSet(pieEntries, "").apply {
            colors = listOf(0xFFC48A3C.toInt(), 0x22FFFFFF.toInt())
            sliceSpace = 2f
            setDrawValues(false)
        }
        b.pieChart.data = PieData(pieSet)
        b.pieChart.centerText = "$rate%"
        b.pieChart.setCenterTextColor(0xFFE8A84A.toInt())
        b.pieChart.setCenterTextSize(16f)
        b.pieChart.invalidate()

        // Highlight selected period button
        val btns = listOf(b.btnDay, b.btnWeek, b.btnMonth, b.btnYear)
        val periods = listOf("day","week","month","year")
        btns.forEachIndexed { i, btn ->
            btn.isSelected = periods[i] == currentPeriod
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}

// ── SummaryRoutineFragment ────────────────────────────────────────────────────
class SummaryRoutineFragment : Fragment() {
    private var _b: FragmentSummaryRoutineBinding? = null
    private val b get() = _b!!
    private val vm: MainViewModel by activityViewModels { MainViewModelFactory(requireActivity().application) }
    private var currentPeriod = "week"

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSummaryRoutineBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        setupPeriodToggle()
        setupChart()
        observeData()
    }

    private fun setupPeriodToggle() {
        listOf(b.btnDay, b.btnWeek, b.btnMonth, b.btnYear).forEachIndexed { i, btn ->
            val periods = listOf("day","week","month","year")
            btn.setOnClickListener { currentPeriod = periods[i]; updateSummary() }
        }
    }

    private fun setupChart() {
        b.barChart.apply {
            description.isEnabled = false; legend.isEnabled = false
            setDrawGridBackground(false); setBackgroundColor(Color.TRANSPARENT)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false); xAxis.textColor = 0xFF6B6254.toInt(); xAxis.textSize = 9f
            axisLeft.gridColor = 0x22FFFFFF; axisLeft.textColor = 0xFF6B6254.toInt(); axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false; animateY(600)
        }
        b.pieChart.apply {
            description.isEnabled = false; legend.isEnabled = false
            isDrawHoleEnabled = true; holeRadius = 68f; transparentCircleRadius = 72f
            setHoleColor(Color.TRANSPARENT); setTransparentCircleColor(Color.TRANSPARENT)
            setBackgroundColor(Color.TRANSPARENT); animateY(800)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            vm.routineChecksSinceYearStart.collect { updateSummary() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            vm.routineItems.collect { updateSummary() }
        }
    }

    private fun updateSummary() {
        val items = vm.routineItems.value
        val checks = vm.routineChecksSinceYearStart.value
        val today = DateUtils.today()
        val now = java.time.LocalDate.now()
        if (items.isEmpty()) { b.tvEmpty.visibility = View.VISIBLE; return }
        b.tvEmpty.visibility = View.GONE

        fun isDone(itemId: Long, dk: String) = checks.any { it.itemId == itemId && it.dateKey == dk && it.isDone }

        val pKeys = when (currentPeriod) {
            "day" -> listOf(today)
            "week" -> DateUtils.currentWeekKeys()
            "month" -> DateUtils.keysInRange(DateUtils.monthStartKey(), today)
            "year" -> DateUtils.keysInRange(DateUtils.yearStartKey(), today)
            else -> listOf(today)
        }

        val totalPossible = items.size * pKeys.size
        val totalDone = items.sumOf { item -> pKeys.count { dk -> isDone(item.id, dk) } }
        val rate = if (totalPossible > 0) (totalDone * 100 / totalPossible) else 0
        val perfectDays = pKeys.count { dk -> items.isNotEmpty() && items.all { isDone(it.id, dk) } }

        b.tvDone.text = "$totalDone"
        b.tvRate.text = "$rate%"
        b.tvPerfect.text = "$perfectDays"

        // Bar data: per week-day
        val wk = DateUtils.currentWeekKeys()
        val barEntries = wk.mapIndexed { i, dk ->
            val d = items.count { item -> isDone(item.id, dk) }
            BarEntry(i.toFloat(), d.toFloat())
        }
        val ds = BarDataSet(barEntries, "Done").apply { color = 0xFFA47AC4.toInt(); setDrawValues(false) }
        b.barChart.data = BarData(ds).apply { barWidth = 0.6f }
        b.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(listOf("Su","Mo","Tu","We","Th","Fr","Sa"))
        b.barChart.xAxis.labelCount = 7
        b.barChart.invalidate()

        // Donut
        val rem = totalPossible - totalDone
        val pe = if (totalPossible > 0) listOf(PieEntry(totalDone.toFloat(),"Done"),PieEntry(rem.toFloat().coerceAtLeast(0f),"Left")) else listOf(PieEntry(1f,""))
        val pds = PieDataSet(pe,"").apply { colors = listOf(0xFFA47AC4.toInt(), 0x22FFFFFF.toInt()); sliceSpace = 2f; setDrawValues(false) }
        b.pieChart.data = PieData(pds)
        b.pieChart.centerText = "$rate%"
        b.pieChart.setCenterTextColor(0xFFA47AC4.toInt())
        b.pieChart.setCenterTextSize(16f)
        b.pieChart.invalidate()

        // Per-item circles (text only for now)
        b.tvItemStats.text = items.take(5).joinToString("\n") { item ->
            val done = pKeys.count { dk -> isDone(item.id, dk) }
            val pct = if (pKeys.isNotEmpty()) done * 100 / pKeys.size else 0
            "• ${item.title}: $pct% ($done/${pKeys.size})"
        }

        val btns = listOf(b.btnDay, b.btnWeek, b.btnMonth, b.btnYear)
        val periods = listOf("day","week","month","year")
        btns.forEachIndexed { i, btn -> btn.isSelected = periods[i] == currentPeriod }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
