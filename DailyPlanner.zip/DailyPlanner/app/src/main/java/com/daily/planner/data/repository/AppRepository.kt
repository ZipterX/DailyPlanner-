package com.daily.planner.data.repository

import com.daily.planner.data.db.*
import com.daily.planner.data.model.*
import kotlinx.coroutines.flow.Flow

class AppRepository(
    private val todoDao: TodoDao,
    private val noteDao: NoteDao,
    private val moodDao: MoodDao,
    private val routineDao: RoutineDao
) {
    // ── Todos ──
    fun getTodosForDate(dateKey: String): Flow<List<Todo>> = todoDao.getTodosForDate(dateKey)
    fun getDailyStats(): Flow<List<DailyStat>> = todoDao.getDailyStats()
    suspend fun insertTodo(todo: Todo) = todoDao.insert(todo)
    suspend fun updateTodo(todo: Todo) = todoDao.update(todo)
    suspend fun deleteTodo(id: Long) = todoDao.deleteById(id)

    // ── Notes ──
    fun getAllNotes(): Flow<List<Note>> = noteDao.getAllNotes()
    suspend fun insertNote(note: Note) = noteDao.insert(note)
    suspend fun updateNote(note: Note) = noteDao.update(note)
    suspend fun deleteNote(id: Long) = noteDao.deleteById(id)

    // ── Moods ──
    fun getMoodForDate(dateKey: String): Flow<Mood?> = moodDao.getMoodForDate(dateKey)
    fun getRecentMoods(): Flow<List<Mood>> = moodDao.getRecentMoods()
    suspend fun setMood(dateKey: String, index: Int) = moodDao.upsert(Mood(dateKey, index))
    suspend fun clearMood(dateKey: String) = moodDao.deleteForDate(dateKey)

    // ── Routines ──
    fun getAllRoutineItems(): Flow<List<RoutineItem>> = routineDao.getAllItems()
    suspend fun insertRoutineItem(item: RoutineItem) = routineDao.insertItem(item)
    suspend fun updateRoutineItem(item: RoutineItem) = routineDao.updateItem(item)
    suspend fun deleteRoutineItem(id: Long) {
        routineDao.deleteChecksForItem(id)
        routineDao.deleteItem(id)
    }
    fun getRoutineChecksForDate(dateKey: String): Flow<List<RoutineCheck>> = routineDao.getChecksForDate(dateKey)
    fun getRoutineChecksSince(fromDate: String): Flow<List<RoutineCheck>> = routineDao.getChecksSince(fromDate)
    suspend fun toggleRoutineCheck(itemId: Long, dateKey: String, currentState: Boolean) {
        if (!currentState) {
            routineDao.upsertCheck(RoutineCheck(itemId, dateKey, true))
        } else {
            routineDao.deleteCheck(itemId, dateKey)
        }
    }
}
